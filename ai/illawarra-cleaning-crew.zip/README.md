# Illawarra Cleaning Crew

Version 0.1.1. An optional Agent Plugins 1.0 package for connecting a compatible
AI client to Illawarra Cleaning Crew's existing public MCP server.

## Customer consent and quote enquiries

Five tools read public information or calculate estimates. `request_quote`
creates a real enquiry and sends customer details to Illawarra Cleaning Crew.
Keep the client's approval for that tool enabled.

Use `request_quote` only after the customer explicitly asks to contact the
business and provides their own name, email, phone and suburb. Explain that
these details will be sent to the business for a reply. Show the intended
service and supplied details before submitting. Never invent contact details,
send a duplicate enquiry to test a connection, or collect payment-card,
participant-number, medical or other unnecessary sensitive information.

A successful enquiry does not reserve a cleaner, confirm a booking or take
payment. The team confirms the service, price and time. Tool responses use
ex-GST base rates and are not a firm quote. Add 10% GST when presenting taxable
consumer estimates and state the inclusive total. Qualifying NDIS supports may
be GST-free when the plan, written agreement and ATO requirements are met; the
team confirms tax treatment in the quote. Do not promise availability or real estate agent
approval, or apply the bond back guarantee without the published terms.

- [Customer privacy](https://www.illawarracrew.com.au/privacy)
- [Service and guarantee terms](https://www.illawarracrew.com.au/terms-of-service)
- [Online booking](https://www.illawarracrew.com.au/booking)
- [Customer support](https://www.illawarracrew.com.au/contact)
- Phone: 0416 592 879

## Install in a compatible client

1. Extract the ZIP into its own folder. `plugin.json` and `mcp.json` must be
   together at that folder's root, alongside this README and `assets/`.
2. If the client supports Agent Plugins 1.0, follow its local plugin installation
   or marketplace instructions and select this folder.
3. Enable its remote MCP connection if prompted. The server uses Streamable
   HTTP and needs no API key or customer account.
4. Inspect the six discovered tools below. Test with a public-information
   question such as "Which services do you offer in Wollongong?"

Installation and support for ZIP uploads vary by client. JSON schema validation
does not prove installation in a specific client. This package contains no
registered platform connection ID or automatic installation mechanism.

If the client supports remote MCP but cannot load this package, add a custom
remote MCP connection using:

```text
Name: Illawarra Cleaning Crew
Transport: Streamable HTTP
URL: https://egnhdhwopbwsnfncjink.supabase.co/functions/v1/mcp
Authentication: None
```

Follow that client's configuration format; `mcp.json` is the Agent Plugins
format and should not replace another client's configuration file. OpenAI's
[connection guide](https://developers.openai.com/plugins/deploy/connect-chatgpt)
describes testing a custom public MCP endpoint on supported clients.

## Available tools

| Tool | Purpose | Side effect |
| --- | --- | --- |
| `get_business_info` | Contact details, public business information and website booking links | Read only |
| `list_services` | Supported cleaning services and pricing approach | Read only |
| `list_service_areas` | Illawarra suburb coverage and location-page links | Read only |
| `estimate_hourly_price` | Estimate an hourly clean for a date, frequency and hours | Read only |
| `estimate_end_of_lease` | Estimate a fixed-price range from property details | Read only |
| `request_quote` | Send a customer-authorised enquiry for the team to confirm | Creates an enquiry and sends customer details |

[Public JSON tool catalogue](https://egnhdhwopbwsnfncjink.supabase.co/functions/v1/mcp/.mcp/list-tools).
Read-only initialization, catalogue and representative hourly estimates were
checked on 6 October 2026. No real quote request was submitted for testing.
The server's existing technical name and title may appear in the client's
connection screen; this package does not change the server or its functions.

The tool catalogue may not list every service shown on the website. For outdoor
services or other requirements not listed, use the website or call the team.
There is no calendar-availability, confirmed-booking or payment tool. NDIS
cleaning supports Self-Managed and Plan-Managed participants only. The business
is not an NDIA-registered provider.

## Distribution and discovery

This is an optional connection package. It does not register the business in
an AI platform's public directory, cause automatic recommendations, or guarantee
search rankings. Public listing needs the platform's identity and domain
verification, required review materials, approval and publication.

The included logo is the website's existing brand asset. A public-directory
submission may require additional listing assets and a review of the category,
privacy disclosures and other platform requirements.

Official format and publication references:

- [Agent Plugins specification](https://agent-plugins.org/specification)
- [OpenAI package format](https://developers.openai.com/plugins/build/plugins)
- [OpenAI public submission](https://developers.openai.com/plugins/deploy/submission)

## Maintain this package

Edit the source in `plugins/illawarra-cleaning-crew/`. Keep the endpoint aligned
with the deployed server and increase `plugin.json`'s version when the package
changes. Validate `plugin.json` and `mcp.json` against their declared official
schemas. Inspect the archive and verify read-only tools after a server change.
Never include credentials, customer data or a real platform connection ID in
this public download.

From the repository root, rebuild the downloadable ZIP with PowerShell:

```powershell
Compress-Archive -Path 'plugins/illawarra-cleaning-crew/*' -DestinationPath 'public/ai/illawarra-cleaning-crew.zip' -Force
```

The ZIP contains the manifest, MCP configuration, this README and the existing
logo. Its public download URL becomes available after the website deployment:
https://www.illawarracrew.com.au/ai/illawarra-cleaning-crew.zip
